import sys
for n in sys.stdin:
	print ( int(n.strip())//2 )

