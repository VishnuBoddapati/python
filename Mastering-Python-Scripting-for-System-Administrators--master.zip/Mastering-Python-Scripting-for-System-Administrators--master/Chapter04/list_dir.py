import os
import sys
print(sorted(os.listdir(sys.argv[1])))

