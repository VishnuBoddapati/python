i = open('sample.txt','r') 
o = open('sample_output.txt','w') 
a = i.read() 
o.write(a)

