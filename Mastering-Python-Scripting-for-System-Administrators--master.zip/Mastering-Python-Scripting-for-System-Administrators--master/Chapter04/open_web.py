import webbrowser
webbrowser.open('https://timesofindia.indiatimes.com/world')

