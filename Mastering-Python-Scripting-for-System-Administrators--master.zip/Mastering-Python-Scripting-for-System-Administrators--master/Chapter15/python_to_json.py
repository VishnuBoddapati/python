import json

emp_dict1 =  '{ "Name":"Harry", "Age":26, "Department":"HR"}'

json_obj = json.dumps(emp_dict1)

print(json_obj)

