import requests

req = requests.get('https://www.imdb.com/news/top?ref_=nv_tp_nw')
print(req)
