# In this script, we are going to create a 4 functions: add_numbers, sub_numbers, mul_numbers, div_numbers.
def add_numbers(x, y):
	return x + y

def sub_numbers(x, y):
	return x - y

def mul_numbers(x, y):
	return x * y

def div_numbers(x, y):
	return (x / y)

