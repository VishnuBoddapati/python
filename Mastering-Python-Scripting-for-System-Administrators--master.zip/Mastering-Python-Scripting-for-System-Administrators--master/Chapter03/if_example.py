def check_if():
	a = int(input("Enter a number \n"))
	if (a == 100):
		print("a is equal to 100")

	else:
		print("a is not equal to 100")

	return a
