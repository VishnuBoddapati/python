import shutil
shutil.make_archive('work', 'zip', 'work')
