import numpy as np

array = np.arange(16)
print("The Array is : ",array)

Square_root = np.sqrt(array)
print("Square root of given array is : ",Square_root) 
