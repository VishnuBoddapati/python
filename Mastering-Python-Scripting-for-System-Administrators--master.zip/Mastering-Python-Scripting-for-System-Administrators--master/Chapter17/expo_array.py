import numpy as np

array = np.arange(16)
print("The Array is : ",array)

exp = np.exp(array)
print("exponential of given array is : ", exp) 
