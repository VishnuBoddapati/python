import numpy as np

my_list1 = [1,2,3,4]
my_array1 = np.array(my_list1)
print(my_array1)

