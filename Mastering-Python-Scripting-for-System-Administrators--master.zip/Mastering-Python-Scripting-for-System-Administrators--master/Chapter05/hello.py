print ("")
print ("Hello World\n")
print ("Hello Python\n")
