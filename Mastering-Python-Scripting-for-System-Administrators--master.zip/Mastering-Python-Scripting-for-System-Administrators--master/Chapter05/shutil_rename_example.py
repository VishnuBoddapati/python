import shutil
shutil.move('sample.bin', 'sample.txt')
