import shutil

shutil.move('/home/student/work/sample.txt', '/home/student/Desktop')
