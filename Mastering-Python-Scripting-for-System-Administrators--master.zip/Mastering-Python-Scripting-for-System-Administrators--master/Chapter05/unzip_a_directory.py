import shutil
shutil.unpack_archive('work1.zip')

