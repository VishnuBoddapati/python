import shutil
import os

shutil.copyfile('hello.py', 'welcome.py')
print("Copy Successful\n")
