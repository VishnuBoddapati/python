import os

os.remove('sample.txt')
print("File removed successfully")

os.rmdir('work1')
print("Directory removed successfully")
