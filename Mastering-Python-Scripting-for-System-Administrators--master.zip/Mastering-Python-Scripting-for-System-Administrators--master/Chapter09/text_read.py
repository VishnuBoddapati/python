text_file = open("test.txt", "r")
data = text_file.read()
print(data)
text_file.close()

