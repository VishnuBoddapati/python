a = 10
if a > 0:
	print("Positive number")
else:
	print("Negative number")

