a = 10
sum = 0
i = 1
while i <= a:
	sum = sum + i
	i = i + 1
print("The sum is", sum)

