#!/usr/bin/python3
print ("Hello this is %s and my age is %d !" % ('John', 25))

