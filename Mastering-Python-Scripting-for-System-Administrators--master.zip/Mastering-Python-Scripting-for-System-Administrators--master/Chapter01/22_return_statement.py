def return_value(a):
	if a >= 0:
		return a
	else:
		return -a
print(return_value(2))
print(return_value(-4))

