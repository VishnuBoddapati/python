def welcome(name):
	print("Hello " + name + ", Welcome to Python Programming !")
welcome("John")

