import sys
print('Number of arguments:', len(sys.argv))
print('Argument list:', str(sys.argv))

