numbers = [6, 5, 3, 8, 4, 2, 5, 4, 11]
sum = 0
for i in numbers:
	sum = sum + i
print("The sum is", sum)

