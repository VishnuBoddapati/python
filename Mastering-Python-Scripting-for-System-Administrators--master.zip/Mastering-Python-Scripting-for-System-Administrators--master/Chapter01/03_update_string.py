#!/usr/bin/python3
str1 = 'Hello Python!'
print("Original String: - ", str1)
print ("Updated String: - ", str1 [:6] + 'John')

