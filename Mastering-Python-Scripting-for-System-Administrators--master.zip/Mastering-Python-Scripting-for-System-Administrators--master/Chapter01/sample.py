def addition(num1, num2):
	result = num1 + num2
	return result

