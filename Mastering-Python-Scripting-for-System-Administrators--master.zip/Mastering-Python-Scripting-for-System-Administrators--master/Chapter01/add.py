import sample
sum = sample.addition(10, 20)
print(sum)

