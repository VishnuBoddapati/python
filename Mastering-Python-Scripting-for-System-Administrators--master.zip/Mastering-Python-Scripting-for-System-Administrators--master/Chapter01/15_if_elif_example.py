a = 10
if a > 50:
    print("a is greater than 50")
elif a == 10:
    print("a is equal to 10")
else:
    print("a is negative")

