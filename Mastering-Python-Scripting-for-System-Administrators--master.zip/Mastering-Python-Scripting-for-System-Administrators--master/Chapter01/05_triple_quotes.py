#!/usr/bin/python3

para_str = """ Python is a scripting language which was created by
Guido van Rossum in 1991, \t which is used in various sectors such as \n Game Development, GIS Programming, Software Development, web development, 
Data Analytics and Machine learning, System Scripting etc.
"""
print (para_str)

