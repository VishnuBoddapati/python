a = 10
if a > 0:
	print(a, "is a positive number.")
print("This statement is always printed.")
a = -10
if a > 0:
	print(a, "is a positive number.")

